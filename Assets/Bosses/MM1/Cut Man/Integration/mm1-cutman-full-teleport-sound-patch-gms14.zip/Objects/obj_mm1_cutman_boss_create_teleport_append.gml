// Append once to existing boss Create.
cmv_teleport_voice = -1;
